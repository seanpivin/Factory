﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FactoryFinalProject.Models
{
    public class empShiftExtra
    {
        public int esId { get; set; }
        public int employeeId { get; set; }
        public int shiftId { get; set; }
        
        
    }
}